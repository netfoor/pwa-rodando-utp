# PROMPT PARA CLAUDE CODE — Rodando UTP (PWA + Backend + Docker + Render)

Pega todo lo que sigue en Claude Code, abierto dentro del repo https://github.com/netfoor/pwa (antes copia la carpeta `frontend-original/` del ZIP a la raíz del repo).

---

Actúa como ingeniero full-stack senior. Trabaja de forma autónoma de principio a fin: planifica, implementa, prueba, haz commits pequeños con mensajes claros y haz push a la rama `main` de este repo. No me hagas preguntas salvo que algo te bloquee por completo; toma decisiones razonables y déjalas anotadas en el README.

## 1. Contexto
"Rodando UTP" es una PWA académica en español (México) para que estudiantes de la Universidad Tecnológica de Puebla compartan raite (carpooling) hacia el campus. Hoy existe solo el frontend estático publicado en https://thriving-marshmallow-87cbe1.netlify.app/ y NO tiene backend: todos los datos son de ejemplo en `js/data.js` y las reservas se guardan en localStorage. Se perdió el repositorio original, pero su código completo está en la carpeta `frontend-original/` de este repo (HTML, CSS, JS vanilla, manifest, sw.js, SVG, iconos, poster y video). Léela COMPLETA antes de escribir código; es la fuente de verdad del diseño y del comportamiento.

## 2. Objetivo
Dejar un proyecto limpio y profesional con:
1. El mismo frontend (idéntico en diseño y comportamiento) pero ahora consumiendo una API real.
2. Un backend REST con base de datos.
3. Docker listo y despliegue en Render, con URL pública funcionando.
4. Código claramente organizado y comentado, porque después se documentará el backend (arquitectura, endpoints, modelo de datos, código) en un reporte académico.

## 3. Stack (usa exactamente esto)
- Backend: Node.js 20 + Express 4 (JavaScript ES modules, sin TypeScript).
- Base de datos: PostgreSQL con `pg` (migraciones SQL simples en `backend/db/migrations/` + script de seed). En local usa PostgreSQL por docker-compose.
- Validación: `zod`. Seguridad: `helmet`, `cors` configurable, `express-rate-limit`. Logs: `morgan`. Auth: JWT (`jsonwebtoken`) + `bcryptjs`. Config con `dotenv`.
- Pruebas: `vitest` + `supertest` (mínimo: health, zonas, raites con filtros, reservas, registro/login, calculadora).
- Documentación de la API: OpenAPI 3 en `backend/openapi.yaml`, servida con Swagger UI en `/api/docs`.
- Frontend: mantén HTML/CSS/JS vanilla (NO migres a React/Vite). Se sirve como estáticos desde el mismo servidor Express (carpeta `frontend/`), para tener un solo contenedor y un solo servicio en Render.

## 4. Estructura de carpetas esperada
```
pwa/
├─ frontend/                 # PWA final (copiada de frontend-original y adaptada a la API)
│  ├─ index.html, manifest.json, sw.js
│  ├─ css/styles.css, js/app.js, js/api.js, img/, video/
├─ backend/
│  ├─ src/
│  │  ├─ server.js           # arranque
│  │  ├─ app.js              # express app (middlewares, rutas, estáticos)
│  │  ├─ config/env.js
│  │  ├─ db/pool.js, db/migrate.js, db/seed.js, db/migrations/*.sql
│  │  ├─ routes/*.routes.js
│  │  ├─ controllers/*.controller.js
│  │  ├─ services/*.service.js   # lógica de negocio (calculadora, reservas)
│  │  ├─ middlewares/ (auth, validate, errorHandler, notFound)
│  │  ├─ schemas/*.schema.js     # zod
│  │  └─ utils/
│  ├─ tests/
│  ├─ openapi.yaml
│  └─ package.json
├─ Dockerfile, docker-compose.yml, .dockerignore, render.yaml, .env.example
├─ docs/ (arquitectura.md, modelo-datos.md con diagrama Mermaid, endpoints.md)
└─ README.md
```
Cada archivo del backend debe llevar un comentario de cabecera de 2–4 líneas explicando su responsabilidad, y las funciones importantes JSDoc.

## 5. Frontend: qué conservar y qué adaptar
Conserva sin cambios visuales: paleta (--primary #FFC21A, --accent #16C47F, --danger #E5484D, --navy #0E1A2B, tema oscuro con [data-theme="dark"]), tipografías Outfit + Inter, header sticky con menú hamburguesa, hero con estadísticas, mapa SVG ilustrado de rutas, secciones (#inicio, #problema, #rutas, #horarios, #calculadora, #como-funciona, #conduce, #seguridad, #testimonios, #faq), video con poster, carrusel de testimonios, modal de reserva, toasts, animaciones .reveal, botón "Instalar app", barra offline y footer completo.

Adapta `js/app.js` para que en lugar de leer `js/data.js` y localStorage use la API mediante un módulo `js/api.js` (fetch con manejo de errores, token JWT en localStorage). Con la API caída o sin internet debe degradar con elegancia: usar la última respuesta cacheada por el service worker/localStorage y mostrar la barra offline. Elimina `data.js` como fuente de verdad (el seed del backend usa esos mismos datos).

Corrige/ mejora en el frontend:
- `manifest.json` ya referencia icon-512 y maskable: verifica que existan.
- `sw.js` (hoy red-primero con caché de respaldo, versión `rodando-utp-v1`): conserva la estrategia, sube la versión a v2, NO caches `/api/*` con estrategia cache-first (para `/api/` usa red primero con fallback a caché solo en GET), y añade los eventos `push` y `notificationclick` (mostrar notificación y abrir `#rutas`).
- Añade un pequeño formulario de acceso/registro (modal) para pasajeros y conductores; solo se aceptan correos `@utpuebla.edu.mx`.

## 6. Modelo de datos (PostgreSQL)
Tablas mínimas: `users` (id, nombre, correo único @utpuebla.edu.mx, password_hash, rol: pasajero|conductor|admin, carrera, cuatrimestre, created_at), `drivers` (user_id, auto, placas, rating, viajes, verificado), `zonas` (id texto, nombre, km, x, y, color, trazo_svg), `raites` (id, zona_id, driver_id, tipo ida|regreso, hora, dias smallint[], asientos, aportacion, paradas text[], activo), `reservas` (id, codigo "RU-XXXX" único, raite_id, user_id, dia 0-5, parada, nombre, estado confirmada|cancelada, created_at; restricción única por (raite_id, user_id, dia)), `testimonios`, `faq`, `config` (precioGasolina 24.3, co2PorLitro 2.31, tarifaUberKm 9.5, tarifaUberBase 35, pasajeTransporte 12), `push_subscriptions` (user_id nullable, endpoint único, p256dh, auth).
El `seed.js` debe cargar exactamente las 8 zonas, los 16 raites, los 4 testimonios, las FAQ y la config que están en `frontend-original/js/data.js` y `index.html`, más un usuario admin y varios conductores de ejemplo (contraseña de demo en el README, no real).

## 7. Endpoints REST (prefijo /api, JSON, respuestas de error uniformes {error:{code,message,details}})
- `GET /api/health` → {status:"ok", db:true, version, uptime}
- Auth: `POST /api/auth/registro`, `POST /api/auth/login`, `GET /api/auth/me`
- `GET /api/zonas` · `GET /api/zonas/:id`
- `GET /api/raites?zona=&turno=manana|tarde|noche&tipo=ida|regreso&libres=true&dia=0-5` → cada raite incluye conductor, auto, paradas, `libres` calculado (asientos − reservas confirmadas del día). Replica la lógica de filtros de la UI (fZona / fTurno / fLibres).
- `GET /api/raites/:id`
- `POST /api/raites` (rol conductor) · `PATCH /api/raites/:id` · `DELETE /api/raites/:id` (solo dueño)
- `POST /api/reservas` {raiteId, dia, parada, nombre} → genera código `RU-XXXX`, valida cupo con transacción (sin sobreventa, probar concurrencia), `GET /api/reservas/mias`, `DELETE /api/reservas/:codigo` (cancela)
- `POST /api/conductores/solicitud` (el formulario "Registro de conductor": nombre, correo institucional, carrera, auto, zona, hora)
- `GET /api/stats` → estudiantes, conductores, toneladas de CO₂ (para el hero)
- `GET /api/testimonios` · `GET /api/faq`
- `GET /api/config`
- `POST /api/calculadora` {rol: conductor|pasajero, km, dias, pasajeros, rendimiento, precio} → devuelve ahorroMes, ahorroCuatri, co2Kg, litros, horas|asientos y barras comparativas. Porta EXACTAMENTE la fórmula de `calcular()` de `frontend-original/js/app.js` al servicio del backend (kmMes = km*2*dias*4.3; litrosMes = kmMes/(rend o 14); modo conductor y modo pasajero con Uber/transporte público). El frontend debe usar este endpoint (con cálculo local de respaldo si está offline).
- Push: `GET /api/push/vapid-public-key`, `POST /api/push/subscribe`, `POST /api/push/send` (solo admin) usando la librería `web-push` y llaves VAPID por variables de entorno. Notifica al conductor cuando alguien aparta lugar.
- Admin mínimo protegido por rol: listar solicitudes de conductor y aprobarlas.

## 8. Docker
- `Dockerfile` multi-stage con `node:20-alpine`, usuario no root, `npm ci --omit=dev`, `HEALTHCHECK` contra `/api/health`, expone `PORT` (por defecto 3000). Copia `frontend/` y `backend/`.
- `docker-compose.yml`: servicios `db` (postgres:16-alpine con volumen y healthcheck) y `web` (build local, depende de db, corre migraciones + seed al iniciar con un script de entrada idempotente). Un solo `docker compose up --build` debe dejar todo funcionando en http://localhost:3000.
- `.env.example` documentado. No subas secretos.

## 9. Render
- `render.yaml` (Blueprint) con: un Web Service de tipo Docker (plan free, `healthCheckPath: /api/health`, autoDeploy) y una base PostgreSQL free enlazada con `DATABASE_URL` vía `fromDatabase`; variables `JWT_SECRET` (generateValue), `VAPID_*`, `NODE_ENV=production`, `ALLOWED_ORIGINS`.
- Soporta SSL en la conexión a Postgres de Render (ssl: { rejectUnauthorized:false } cuando NODE_ENV=production).
- Las migraciones y el seed corren automáticamente al arrancar (idempotentes).
- En el README, sección "Despliegue en Render" paso a paso (crear Blueprint desde el repo, qué variables llenar, cómo ver logs, nota del plan free que duerme tras inactividad).
- Si tienes credenciales/herramientas para desplegar, hazlo; si no, deja todo listo y dime exactamente los clics necesarios.

## 10. Calidad y criterios de aceptación
- `npm test` en `backend/` pasa en verde; ESLint sin errores.
- `docker compose up --build` levanta la app y `curl localhost:3000/api/health` responde ok.
- Lighthouse PWA: instalable (manifest + sw + HTTPS), funciona offline para la parte estática, sin errores en consola.
- Revisa visualmente con Playwright (capturas desktop 1440 y móvil 390) que el frontend se vea igual que `frontend-original`; reporta diferencias.
- Probar manualmente flujo completo: registro → login → filtrar raites → apartar lugar (código RU-XXXX) → ver "Mis viajes" → cancelar → calculadora conductor y pasajero.
- README completo: descripción, arquitectura (diagrama Mermaid), cómo correr local, variables de entorno, tabla de endpoints, modelo de datos, pruebas, despliegue en Render, y créditos académicos genéricos (proyecto de la UTP). No menciones pérdida de código ni autores individuales.
- Commits en español o inglés consistentes, y al final `git push origin main` y un resumen de lo hecho, URL de Render (si hay) y pendientes.

Empieza leyendo `frontend-original/` y proponiéndome en 10 líneas tu plan; luego ejecútalo sin esperar confirmación.
