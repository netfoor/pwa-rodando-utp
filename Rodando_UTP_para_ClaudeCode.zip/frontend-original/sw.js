/* =========================================================
   Rodando UTP · Service Worker
   Red primero y caché de respaldo: siempre muestra lo más
   nuevo, pero funciona sin internet.
   (Sube la versión al cambiar archivos.)
   ========================================================= */
const CACHE = "rodando-utp-v1";
const ARCHIVOS = [
  "./",
  "./index.html",
  "./css/styles.css",
  "./js/data.js",
  "./js/app.js",
  "./manifest.json",
  "./img/logo.svg",
  "./img/hero.svg",
  "./img/paso-1.svg",
  "./img/paso-2.svg",
  "./img/paso-3.svg",
  "./img/conductor.svg",
  "./img/icons/icon-192.png",
  "./img/icons/icon-512.png",
  "./video/poster.png"
];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ARCHIVOS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET" || req.headers.has("range")) return; // el video se transmite por rangos
  e.respondWith(
    fetch(req, { cache: "no-cache" })
      .then(res => {
        if (res.ok && (req.url.startsWith(self.location.origin) || req.url.includes("fonts.g"))) {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(req, copy));
        }
        return res;
      })
      .catch(() => caches.match(req).then(r => r || caches.match("./index.html")))
  );
});
