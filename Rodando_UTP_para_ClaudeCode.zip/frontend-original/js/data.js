/* =========================================================
   Rodando UTP · Datos de la app
   (datos de ejemplo para el prototipo — proyecto académico)
   ========================================================= */

// Zonas de Puebla desde donde salen raites hacia la UTP.
// x / y = posición en el mapa ilustrado (viewBox 0 0 600 420)
// km = distancia aproximada hasta la UTP
const ZONAS = [
  { id: "centro",      nombre: "Centro Histórico",     km: 8,  x: 255, y: 235, color: "#FF8A3D" },
  { id: "amalucan",    nombre: "Bosques de Amalucan",  km: 5,  x: 395, y: 225, color: "#16C47F" },
  { id: "xonaca",      nombre: "Xonacatepec",          km: 9,  x: 525, y: 70,  color: "#8B5CF6" },
  { id: "amozoc",      nombre: "Amozoc",               km: 13, x: 545, y: 285, color: "#EF4444" },
  { id: "cu",          nombre: "CU · San Manuel",      km: 12, x: 285, y: 335, color: "#0EA5E9" },
  { id: "angelopolis", nombre: "Angelópolis",          km: 17, x: 145, y: 355, color: "#EC4899" },
  { id: "cholula",     nombre: "Cholula",              km: 20, x: 60,  y: 245, color: "#F59E0B" },
  { id: "croc",        nombre: "CROC · Rivera Anaya",  km: 6,  x: 300, y: 110, color: "#14B8A6" }
];

// Punto de destino: la universidad
const UTP = { nombre: "UTP", x: 440, y: 140 };

// Trazo de cada ruta en el mapa (curvas SVG hacia la UTP)
const TRAZOS = {
  centro:      "M255 235 C 300 225, 330 190, 360 175 S 420 150, 440 140",
  amalucan:    "M395 225 C 405 200, 420 170, 440 140",
  xonaca:      "M525 70 C 500 95, 470 110, 440 140",
  amozoc:      "M545 285 C 520 240, 490 200, 470 175 S 450 150, 440 140",
  cu:          "M285 335 C 290 290, 320 260, 350 230 S 410 170, 440 140",
  angelopolis: "M145 355 C 190 320, 230 300, 270 270 S 350 200, 380 175 S 425 148, 440 140",
  cholula:     "M60 245 C 110 230, 160 225, 210 215 S 330 185, 380 165 S 425 145, 440 140",
  croc:        "M300 110 C 340 105, 390 115, 440 140"
};

const DIAS = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];

// Raites publicados por estudiantes conductores
const RAITES = [
  { id: 1,  zona: "centro",      tipo: "ida",     hora: "06:20", dias: [0,1,2,3,4],   asientos: 4, aportacion: 25,
    conductor: { nombre: "Mariana López",   carrera: "Ing. en Software",       cuatri: 7,  rating: 4.9, viajes: 132 },
    auto: "Nissan March gris", paradas: ["Zócalo", "Paseo Bravo", "Blvd. 5 de Mayo"] },
  { id: 2,  zona: "centro",      tipo: "regreso", hora: "14:15", dias: [0,1,2,3,4],   asientos: 3, aportacion: 25,
    conductor: { nombre: "Mariana López",   carrera: "Ing. en Software",       cuatri: 7,  rating: 4.9, viajes: 132 },
    auto: "Nissan March gris", paradas: ["Blvd. 5 de Mayo", "Paseo Bravo", "Zócalo"] },
  { id: 3,  zona: "amalucan",    tipo: "ida",     hora: "06:40", dias: [0,1,2,3,4],   asientos: 3, aportacion: 15,
    conductor: { nombre: "Diego Hernández", carrera: "Mecatrónica",            cuatri: 4,  rating: 4.7, viajes: 58 },
    auto: "VW Vento blanco", paradas: ["Parque Amalucan", "Bosques 1ª secc.", "Blvd. Xonaca"] },
  { id: 4,  zona: "xonaca",      tipo: "ida",     hora: "06:30", dias: [0,1,2,3,4,5], asientos: 4, aportacion: 20,
    conductor: { nombre: "Fernanda Ruiz",   carrera: "Negocios Internacionales", cuatri: 10, rating: 5.0, viajes: 210 },
    auto: "Chevrolet Aveo rojo", paradas: ["Xonacatepec centro", "Autopista (puente)", "San Pablo Xochimehuacan"] },
  { id: 5,  zona: "amozoc",      tipo: "ida",     hora: "06:05", dias: [0,1,2,3,4],   asientos: 4, aportacion: 30,
    conductor: { nombre: "Óscar Pérez",     carrera: "Energías Renovables",    cuatri: 7,  rating: 4.8, viajes: 97 },
    auto: "Toyota Yaris azul", paradas: ["Amozoc centro", "Casa Blanca", "Autopista a Orizaba"] },
  { id: 6,  zona: "amozoc",      tipo: "regreso", hora: "20:10", dias: [0,1,2,3,4],   asientos: 4, aportacion: 30,
    conductor: { nombre: "Óscar Pérez",     carrera: "Energías Renovables",    cuatri: 7,  rating: 4.8, viajes: 97 },
    auto: "Toyota Yaris azul", paradas: ["Autopista a Orizaba", "Casa Blanca", "Amozoc centro"] },
  { id: 7,  zona: "cu",          tipo: "ida",     hora: "06:10", dias: [0,2,4],       asientos: 3, aportacion: 28,
    conductor: { nombre: "Valeria Sánchez", carrera: "Ing. en Software",       cuatri: 10, rating: 4.9, viajes: 164 },
    auto: "Kia Rio negro", paradas: ["CU BUAP", "Plaza San Manuel", "Blvd. Valsequillo"] },
  { id: 8,  zona: "angelopolis", tipo: "ida",     hora: "05:55", dias: [0,1,2,3,4],   asientos: 4, aportacion: 35,
    conductor: { nombre: "Rodrigo Castillo", carrera: "Mantenimiento Industrial", cuatri: 7, rating: 4.6, viajes: 71 },
    auto: "Mazda 2 plata", paradas: ["Plaza Angelópolis", "Periférico", "Blvd. Atlixcáyotl"] },
  { id: 9,  zona: "angelopolis", tipo: "regreso", hora: "15:00", dias: [0,1,2,3,4],   asientos: 4, aportacion: 35,
    conductor: { nombre: "Rodrigo Castillo", carrera: "Mantenimiento Industrial", cuatri: 7, rating: 4.6, viajes: 71 },
    auto: "Mazda 2 plata", paradas: ["Blvd. Atlixcáyotl", "Periférico", "Plaza Angelópolis"] },
  { id: 10, zona: "cholula",     tipo: "ida",     hora: "05:45", dias: [0,1,2,3,4],   asientos: 3, aportacion: 40,
    conductor: { nombre: "Andrea Morales",  carrera: "Tecnologías de la Información", cuatri: 4, rating: 4.8, viajes: 45 },
    auto: "Honda City blanco", paradas: ["Zócalo de Cholula", "Recta a Cholula", "Las Ánimas"] },
  { id: 11, zona: "croc",        tipo: "ida",     hora: "06:45", dias: [0,1,2,3,4,5], asientos: 4, aportacion: 12,
    conductor: { nombre: "Luis Ángel Torres", carrera: "Mecatrónica",           cuatri: 1,  rating: 4.5, viajes: 12 },
    auto: "Nissan Versa gris", paradas: ["Unidad CROC", "Manuel Rivera Anaya", "Diagonal Defensores"] },
  { id: 12, zona: "croc",        tipo: "regreso", hora: "14:05", dias: [0,1,2,3,4],   asientos: 4, aportacion: 12,
    conductor: { nombre: "Luis Ángel Torres", carrera: "Mecatrónica",           cuatri: 1,  rating: 4.5, viajes: 12 },
    auto: "Nissan Versa gris", paradas: ["Diagonal Defensores", "Manuel Rivera Anaya", "Unidad CROC"] },
  { id: 13, zona: "centro",      tipo: "ida",     hora: "12:40", dias: [0,1,2,3,4],   asientos: 3, aportacion: 25,
    conductor: { nombre: "Sofía Jiménez",   carrera: "Procesos Industriales",  cuatri: 4,  rating: 4.9, viajes: 88 },
    auto: "Seat Ibiza rojo", paradas: ["Los Fuertes", "Blvd. Héroes del 5 de Mayo", "Xonaca"] },
  { id: 14, zona: "xonaca",      tipo: "regreso", hora: "20:15", dias: [0,1,2,3,4],   asientos: 4, aportacion: 20,
    conductor: { nombre: "Fernanda Ruiz",   carrera: "Negocios Internacionales", cuatri: 10, rating: 5.0, viajes: 210 },
    auto: "Chevrolet Aveo rojo", paradas: ["San Pablo Xochimehuacan", "Autopista (puente)", "Xonacatepec centro"] },
  { id: 15, zona: "cu",          tipo: "regreso", hora: "14:30", dias: [0,2,4],       asientos: 3, aportacion: 28,
    conductor: { nombre: "Valeria Sánchez", carrera: "Ing. en Software",       cuatri: 10, rating: 4.9, viajes: 164 },
    auto: "Kia Rio negro", paradas: ["Blvd. Valsequillo", "Plaza San Manuel", "CU BUAP"] },
  { id: 16, zona: "amalucan",    tipo: "regreso", hora: "19:50", dias: [0,1,2,3,4],   asientos: 3, aportacion: 15,
    conductor: { nombre: "Diego Hernández", carrera: "Mecatrónica",            cuatri: 4,  rating: 4.7, viajes: 58 },
    auto: "VW Vento blanco", paradas: ["Blvd. Xonaca", "Bosques 1ª secc.", "Parque Amalucan"] }
];

// Ocupación simulada (lugares ya apartados por otros estudiantes)
const OCUPADOS = { 1: 2, 2: 1, 3: 1, 4: 3, 5: 1, 6: 2, 7: 2, 8: 1, 9: 3, 10: 2, 11: 0, 12: 1, 13: 1, 14: 2, 15: 1, 16: 3 };

const TESTIMONIOS = [
  { texto: "Antes gastaba casi $900 al mes en gasolina viniendo desde Angelópolis. Ahora llevo a tres compas y me sale en menos de la mitad.", nombre: "Rodrigo C.", rol: "Conductor · Mantenimiento Industrial" },
  { texto: "Tomaba dos combis y un camión. Con Rodando llego en 25 minutos y hasta desayuno tranquila.", nombre: "Karla M.", rol: "Pasajera · Ing. en Software" },
  { texto: "Lo mejor es que solo entran alumnos verificados con correo de la UTP. Mis papás se quedan tranquilos.", nombre: "Paola G.", rol: "Pasajera · Negocios Internacionales" },
  { texto: "Ya hicimos grupo fijo para ir a la estadía. Nos turnamos el coche y cero estrés por el estacionamiento.", nombre: "Jorge L.", rol: "Conductor · Mecatrónica" }
];

const CONFIG = {
  precioGasolina: 24.3,   // $/litro Magna (aprox. Puebla 2026)
  co2PorLitro: 2.31,      // kg de CO₂ por litro de gasolina
  tarifaUberKm: 9.5,      // $/km aprox.
  tarifaUberBase: 35,
  pasajeTransporte: 12    // $ por camión/combi
};
