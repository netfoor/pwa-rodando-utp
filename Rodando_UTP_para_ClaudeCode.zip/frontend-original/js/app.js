/* =========================================================
   Rodando UTP · Lógica de la página
   ========================================================= */

const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
const zonaById = id => ZONAS.find(z => z.id === id);
const money = n => "$" + Math.round(n).toLocaleString("es-MX");
const turnoDe = hora => (parseInt(hora) < 12 ? "matutino" : "vespertino");
const initials = nombre => nombre.split(" ").map(p => p[0]).slice(0, 2).join("");

// LocalStorage seguro (puede fallar en modo privado)
const store = {
  get(k, def) { try { return JSON.parse(localStorage.getItem(k)) ?? def; } catch { return def; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* sin almacenamiento */ } }
};

/* ---------------- Tema claro / oscuro ---------------- */
const root = document.documentElement;
const savedTheme = store.get("ru-theme", null);
if (savedTheme) root.dataset.theme = savedTheme;
else if (matchMedia("(prefers-color-scheme: dark)").matches) root.dataset.theme = "dark";

$("#themeBtn").addEventListener("click", () => {
  const next = root.dataset.theme === "dark" ? "light" : "dark";
  root.dataset.theme = next;
  store.set("ru-theme", next);
});

/* ---------------- Encabezado y navegación ---------------- */
const header = $("#header");
const nav = $("#nav");
const burger = $("#burger");

burger.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  burger.setAttribute("aria-expanded", open);
});
$$(".nav__link").forEach(a => a.addEventListener("click", () => {
  nav.classList.remove("open");
  burger.setAttribute("aria-expanded", false);
}));

// Resalta el enlace de la sección visible (scrollspy)
const navLinks = $$(".nav__link");
const spySections = navLinks.map(a => $(a.getAttribute("href")));
function onScroll() {
  const y = scrollY;
  header.classList.toggle("scrolled", y > 10);
  $("#toTop").classList.toggle("show", y > 700);

  let current = spySections[0];
  for (const s of spySections) if (s && s.offsetTop - 140 <= y) current = s;
  // Al final de la página, marcar la última sección
  if (innerHeight + y >= document.body.scrollHeight - 4) current = spySections[spySections.length - 1];
  navLinks.forEach(a => a.classList.toggle("active", a.getAttribute("href") === "#" + current.id));
}
addEventListener("scroll", onScroll, { passive: true });
$("#toTop").addEventListener("click", () => scrollTo({ top: 0 }));

/* ---------------- Animaciones al hacer scroll ---------------- */
const revealObs = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add("visible"); revealObs.unobserve(e.target); }
  });
}, { threshold: 0.12 });
$$(".reveal").forEach(el => revealObs.observe(el));

// Contadores animados del hero
const countObs = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (!e.isIntersecting) return;
    const el = e.target, target = +el.dataset.count, suffix = el.dataset.suffix || "";
    const t0 = performance.now();
    const tick = t => {
      const p = Math.min((t - t0) / 1600, 1);
      el.textContent = Math.round(target * (1 - Math.pow(1 - p, 3))).toLocaleString("es-MX") + suffix;
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
    countObs.unobserve(el);
  });
});
$$("[data-count]").forEach(el => countObs.observe(el));

// Texto que rota en el título
const palabras = ["a clase", "al examen", "a la estadía", "temprano", "seguro"];
let iPalabra = 0;
setInterval(() => {
  const r = $("#rotator");
  iPalabra = (iPalabra + 1) % palabras.length;
  r.animate([{ opacity: 1, transform: "translateY(0)" }, { opacity: 0, transform: "translateY(-12px)" }], { duration: 200 })
    .onfinish = () => {
      r.textContent = palabras[iPalabra];
      r.animate([{ opacity: 0, transform: "translateY(12px)" }, { opacity: 1, transform: "translateY(0)" }], { duration: 250 });
    };
}, 2600);

/* ---------------- Llenar selects de zonas ---------------- */
function fillZonas(sel, conTodas) {
  sel.innerHTML = (conTodas ? `<option value="todas">Todas las zonas</option>` : "") +
    ZONAS.map(z => `<option value="${z.id}">${z.nombre} · ${z.km} km</option>`).join("");
}
fillZonas($("#heroZona"), true);
fillZonas($("#fZona"), true);
fillZonas($("#cZona"), false);
fillZonas($("#dZona"), false);

/* ---------------- Reservaciones (lugares apartados) ---------------- */
let reservas = store.get("ru-reservas", []);
const libres = r => r.asientos - (OCUPADOS[r.id] || 0) - reservas.filter(x => x.rideId === r.id).length;

/* ---------------- MAPA ---------------- */
const map = $("#map");
const NS = "http://www.w3.org/2000/svg";
let selectedRide = null;

function buildMap() {
  // Fondo: manzanas, calles y parques (decorativo)
  let bg = `<rect class="m-bg" width="600" height="420" rx="18"/>`;
  const rnd = mulberry(7);
  for (let x = 10; x < 600; x += 58) {
    for (let y = 10; y < 420; y += 50) {
      if (rnd() > 0.82) bg += `<rect class="m-park" x="${x}" y="${y}" width="50" height="42" rx="8"/>`;
      else bg += `<rect class="m-block" x="${x}" y="${y}" width="50" height="42" rx="6"/>`;
    }
  }
  bg += `<path class="m-street" d="M0 200 C 150 190, 300 150, 600 120"/>
         <path class="m-street" d="M200 0 C 230 150, 260 280, 240 420"/>
         <path class="m-street" d="M0 330 C 200 300, 420 330, 600 260" />
         <path class="m-street" d="M600 30 C 480 120, 420 300, 470 420"/>`;
  map.innerHTML = bg;

  // Rutas
  ZONAS.forEach(z => {
    const p = document.createElementNS(NS, "path");
    p.setAttribute("d", TRAZOS[z.id]);
    p.setAttribute("class", "m-route");
    p.setAttribute("stroke", z.color);
    p.dataset.zona = z.id;
    p.addEventListener("click", () => selectZona(z.id));
    map.appendChild(p);
  });

  // Coche que recorre la ruta seleccionada
  const car = document.createElementNS(NS, "g");
  car.setAttribute("class", "m-car");
  car.setAttribute("opacity", "0");
  car.innerHTML = `<circle r="15" fill="#FFC21A" stroke="#0E1A2B" stroke-width="3"/>
    <text y="5" text-anchor="middle" font-size="15">🚗</text>`;
  map.appendChild(car);

  // Nodos de zonas
  ZONAS.forEach(z => {
    const g = document.createElementNS(NS, "g");
    g.setAttribute("class", "m-node");
    const anchor = z.x > 480 ? "end" : z.x < 120 ? "start" : "middle";
    const ty = z.y > 300 ? 28 : -16;
    g.innerHTML = `<circle cx="${z.x}" cy="${z.y}" r="9" fill="${z.color}"/>
      <text x="${z.x}" y="${z.y + ty}" text-anchor="${anchor}">${z.nombre}</text>`;
    g.addEventListener("click", () => selectZona(z.id));
    map.appendChild(g);
  });

  // Destino: UTP
  const utp = document.createElementNS(NS, "g");
  utp.setAttribute("class", "m-utp");
  utp.innerHTML = `<rect x="${UTP.x - 36}" y="${UTP.y - 20}" width="72" height="40" rx="12"/>
    <text x="${UTP.x}" y="${UTP.y + 5}" text-anchor="middle">🎓 UTP</text>`;
  map.appendChild(utp);

  // Leyenda
  $("#mapLegend").innerHTML = ZONAS.map(z =>
    `<button class="legend-chip" data-zona="${z.id}"><i style="background:${z.color}"></i>${z.nombre}</button>`).join("");
  $$(".legend-chip").forEach(b => b.addEventListener("click", () => selectZona(b.dataset.zona)));
}

// Generador pseudoaleatorio con semilla (el mapa siempre sale igual)
function mulberry(a) {
  return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}

let carAnim = null;
function highlightRoute(zonaId, reverse = false) {
  $$(".m-route", map).forEach(p => p.classList.toggle("on", p.dataset.zona === zonaId));
  $$(".legend-chip").forEach(c => c.classList.toggle("on", c.dataset.zona === zonaId));
  const car = $(".m-car", map);
  cancelAnimationFrame(carAnim);
  if (!zonaId) { car.setAttribute("opacity", 0); return; }
  const path = $(`.m-route[data-zona="${zonaId}"]`, map);
  const len = path.getTotalLength();
  car.setAttribute("opacity", 1);
  const t0 = performance.now(), dur = 2600 + len * 6;
  const step = t => {
    let p = ((t - t0) % (dur + 600)) / dur;
    p = Math.min(p, 1);
    const pt = path.getPointAtLength((reverse ? 1 - p : p) * len);
    car.setAttribute("transform", `translate(${pt.x} ${pt.y})`);
    carAnim = requestAnimationFrame(step);
  };
  carAnim = requestAnimationFrame(step);
}

function selectZona(id) {
  $("#fZona").value = id;
  filters.zona = id;
  renderRides();
  highlightRoute(id);
}

/* ---------------- LISTA DE RAITES ---------------- */
const filters = { zona: "todas", tipo: "todos", turno: "todos", soloLibres: false };

function rideCard(r) {
  const z = zonaById(r.zona);
  const free = Math.max(libres(r), 0);
  const seats = Array.from({ length: r.asientos }, (_, i) => `<i class="${i < free ? "free" : ""}"></i>`).join("");
  const ruta = r.tipo === "ida" ? `${z.nombre} → UTP` : `UTP → ${z.nombre}`;
  return `
    <article class="ride ${selectedRide === r.id ? "on" : ""}" data-id="${r.id}" style="--zc:${z.color}" tabindex="0">
      <div class="avatar" style="background:${z.color}">${initials(r.conductor.nombre)}</div>
      <div class="ride__main">
        <div class="ride__top">
          <span class="ride__time">${r.hora}</span>
          <span class="tag tag--${r.tipo}">${r.tipo}</span>
        </div>
        <div class="ride__route">${ruta}</div>
        <div class="ride__meta">${r.conductor.nombre} · ⭐ ${r.conductor.rating} · ${r.auto}</div>
      </div>
      <div class="ride__side">
        <div class="price">${money(r.aportacion)}<small>aportación</small></div>
        ${free > 0 ? `<div class="seats" title="${free} lugares libres">${seats}</div>` : `<span class="full-badge">LLENO</span>`}
      </div>
    </article>`;
}

function renderRides() {
  const list = RAITES.filter(r =>
    (filters.zona === "todas" || r.zona === filters.zona) &&
    (filters.tipo === "todos" || r.tipo === filters.tipo) &&
    (filters.turno === "todos" || turnoDe(r.hora) === filters.turno) &&
    (!filters.soloLibres || libres(r) > 0)
  ).sort((a, b) => a.hora.localeCompare(b.hora));

  $("#ridesCount").textContent = `${list.length} raite${list.length === 1 ? "" : "s"} encontrado${list.length === 1 ? "" : "s"}`;
  $("#ridesList").innerHTML = list.length
    ? list.map(rideCard).join("")
    : `<div class="empty">😕 No hay raites con esos filtros.<br>Prueba otra zona u horario.</div>`;

  $$(".ride").forEach(el => {
    const open = () => {
      const r = RAITES.find(x => x.id === +el.dataset.id);
      selectedRide = r.id;
      $$(".ride").forEach(c => c.classList.toggle("on", c === el));
      highlightRoute(r.zona, r.tipo === "regreso");
      openReserva(r);
    };
    el.addEventListener("click", open);
    el.addEventListener("keydown", e => { if (e.key === "Enter") open(); });
  });
}

$("#fZona").addEventListener("change", e => {
  filters.zona = e.target.value;
  renderRides();
  highlightRoute(filters.zona === "todas" ? null : filters.zona);
});
$("#fTurno").addEventListener("change", e => { filters.turno = e.target.value; renderRides(); });
$("#fLibres").addEventListener("change", e => { filters.soloLibres = e.target.checked; renderRides(); });
$$("[data-tipo]").forEach(b => b.addEventListener("click", () => {
  $$("[data-tipo]").forEach(x => x.classList.toggle("active", x === b));
  filters.tipo = b.dataset.tipo;
  renderRides();
}));

// Búsqueda desde el hero
$("#heroSearch").addEventListener("submit", e => {
  e.preventDefault();
  filters.zona = $("#heroZona").value;
  filters.turno = $("#heroTurno").value;
  $("#fZona").value = filters.zona;
  $("#fTurno").value = filters.turno;
  renderRides();
  highlightRoute(filters.zona === "todas" ? null : filters.zona);
  $("#rutas").scrollIntoView();
});

/* ---------------- MODAL: apartar lugar ---------------- */
const modal = $("#modal");
function openModal(html) {
  $("#modalBody").innerHTML = html;
  modal.hidden = false;
  document.body.style.overflow = "hidden";
}
function closeModal() {
  modal.hidden = true;
  document.body.style.overflow = "";
}
modal.addEventListener("click", e => { if (e.target.closest("[data-close]")) closeModal(); });
addEventListener("keydown", e => { if (e.key === "Escape" && !modal.hidden) closeModal(); });

function openReserva(r) {
  const z = zonaById(r.zona);
  const free = libres(r);
  const hoy = (new Date().getDay() + 6) % 7; // 0 = lunes
  const primerDia = r.dias.find(d => d >= hoy) ?? r.dias[0];
  const destino = r.tipo === "ida" ? [...r.paradas, "UTP · Puerta principal"] : ["UTP · Puerta principal", ...r.paradas];

  openModal(`
    <h3 id="modalTitle">${r.tipo === "ida" ? z.nombre + " → UTP" : "UTP → " + z.nombre}</h3>
    <p style="color:var(--muted);margin:0">Sale a las <b style="color:var(--ink)">${r.hora}</b> · ${free > 0 ? free + " lugar" + (free > 1 ? "es" : "") + " libre" + (free > 1 ? "s" : "") : "sin lugares"}</p>
    <div class="m-driver">
      <div class="avatar" style="background:${z.color}">${initials(r.conductor.nombre)}</div>
      <div><b>${r.conductor.nombre}</b><small>${r.conductor.carrera} · ${r.conductor.cuatri}° cuatri · ⭐ ${r.conductor.rating} (${r.conductor.viajes} viajes)</small><small>🚗 ${r.auto}</small></div>
    </div>
    <ul class="stops" style="--zc:${z.color}">${destino.map(p => `<li>${p}</li>`).join("")}</ul>
    <p style="font-weight:700;margin-bottom:8px">¿Qué día viajas?</p>
    <div class="pick-days">${DIAS.map((d, i) => `<button type="button" data-dia="${i}" ${r.dias.includes(i) ? "" : "disabled"} class="${i === primerDia ? "active" : ""}">${d}</button>`).join("")}</div>
    <label class="field"><span>Tu nombre</span><input type="text" id="rNombre" placeholder="¿Cómo te llamas?" value="${store.get("ru-nombre", "")}"></label>
    <label class="field"><span>¿Dónde te subes?</span><select id="rParada">${(r.tipo === "ida" ? r.paradas : ["UTP · Puerta principal"]).map(p => `<option>${p}</option>`).join("")}</select></label>
    <button class="btn btn--primary btn--lg btn--block" id="rOk" ${free > 0 ? "" : "disabled"}>${free > 0 ? `Apartar lugar · ${money(r.aportacion)}` : "Raite lleno"}</button>
  `);

  let dia = primerDia;
  $$(".pick-days button").forEach(b => b.addEventListener("click", () => {
    dia = +b.dataset.dia;
    $$(".pick-days button").forEach(x => x.classList.toggle("active", x === b));
  }));

  $("#rOk").addEventListener("click", () => {
    const nombre = $("#rNombre").value.trim();
    if (!nombre) { $("#rNombre").focus(); $("#rNombre").closest(".field").classList.add("invalid"); return; }
    store.set("ru-nombre", nombre);
    const code = "RU-" + Math.random().toString(36).slice(2, 6).toUpperCase();
    reservas.push({ code, rideId: r.id, dia, parada: $("#rParada").value, nombre });
    store.set("ru-reservas", reservas);
    renderRides(); renderMyTrips(); renderTimeline();
    openModal(`
      <div class="success">
        <div class="success__icon">✓</div>
        <h3 style="margin-right:0">¡Lugar apartado, ${nombre.split(" ")[0]}!</h3>
        <p style="color:var(--muted)">${DIAS[dia]} a las ${r.hora} con ${r.conductor.nombre.split(" ")[0]}.<br>Muestra este código al subir:</p>
        <code>${code}</code>
        <button class="btn btn--dark btn--block" data-close>Listo</button>
      </div>`);
    toast("🎉 Tu lugar quedó apartado");
  });
}

/* ---------------- Mis viajes ---------------- */
function renderMyTrips() {
  $("#myTrips").hidden = reservas.length === 0;
  $("#myTripsList").innerHTML = reservas.map(v => {
    const r = RAITES.find(x => x.id === v.rideId);
    const z = zonaById(r.zona);
    return `<div class="ticket" style="--zc:${z.color}">
      <b>${DIAS[v.dia]} · ${r.hora}</b>
      <p>${r.tipo === "ida" ? z.nombre + " → UTP" : "UTP → " + z.nombre}</p>
      <p>Te subes en: ${v.parada}</p>
      <p>Código: <code>${v.code}</code></p>
      <button data-cancel="${v.code}">Cancelar</button>
    </div>`;
  }).join("");
  $$("[data-cancel]").forEach(b => b.addEventListener("click", () => {
    reservas = reservas.filter(v => v.code !== b.dataset.cancel);
    store.set("ru-reservas", reservas);
    renderRides(); renderMyTrips(); renderTimeline();
    toast("Reservación cancelada");
  }));
}

/* ---------------- HORARIOS ---------------- */
const hoyIdx = (new Date().getDay() + 6) % 7; // 0 = lunes … 6 = domingo
let diaSel = hoyIdx > 5 ? 0 : hoyIdx;

function renderDayTabs() {
  $("#dayTabs").innerHTML = DIAS.map((d, i) =>
    `<button class="day-tab ${i === diaSel ? "active" : ""}" role="tab" data-d="${i}">${d}${i === hoyIdx ? '<span class="today">HOY</span>' : ""}</button>`).join("");
  $$(".day-tab").forEach(b => b.addEventListener("click", () => { diaSel = +b.dataset.d; renderDayTabs(); renderTimeline(); }));
}

function renderTimeline() {
  const list = RAITES.filter(r => r.dias.includes(diaSel)).sort((a, b) => a.hora.localeCompare(b.hora));
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const esHoy = diaSel === hoyIdx;
  const toMin = h => { const [a, b] = h.split(":").map(Number); return a * 60 + b; };
  const next = esHoy ? list.find(r => toMin(r.hora) >= nowMin) : null;

  const grupos = { "🌅 Mañana": [], "☀️ Tarde": [], "🌙 Noche": [] };
  list.forEach(r => {
    const m = toMin(r.hora);
    (m < 720 ? grupos["🌅 Mañana"] : m < 1080 ? grupos["☀️ Tarde"] : grupos["🌙 Noche"]).push(r);
  });

  let html = "", nowDrawn = !esHoy;
  for (const [titulo, items] of Object.entries(grupos)) {
    if (!items.length) continue;
    html += `<div class="t-group"><h4>${titulo}</h4>`;
    items.forEach(r => {
      const m = toMin(r.hora), z = zonaById(r.zona);
      if (!nowDrawn && m >= nowMin) { html += `<div class="now-line">AHORA · ${now.toTimeString().slice(0, 5)}</div>`; nowDrawn = true; }
      const past = esHoy && m < nowMin;
      const falta = m - nowMin;
      const badge = r === next
        ? `<span class="t-badge">Sale en ${falta >= 60 ? Math.floor(falta / 60) + " h " + (falta % 60) + " min" : falta + " min"}</span>`
        : `<span style="font-weight:700">${(n => n === 0 ? "Lleno" : n + (n === 1 ? " lugar" : " lugares"))(Math.max(libres(r), 0))}</span>`;
      html += `<div class="t-item ${past ? "past" : ""} ${r === next ? "next" : ""}" style="--zc:${z.color}">
        <span class="t-time">${r.hora}</span>
        <div class="t-info"><b>${r.tipo === "ida" ? z.nombre + " → UTP" : "UTP → " + z.nombre}</b><small>${r.conductor.nombre} · ${money(r.aportacion)}</small></div>
        ${badge}
      </div>`;
    });
    html += `</div>`;
  }
  if (!nowDrawn) html += `<div class="now-line">AHORA · ${now.toTimeString().slice(0, 5)} · ya salieron todos los raites de hoy</div>`;
  $("#timeline").innerHTML = html || `<div class="empty">No hay salidas este día.</div>`;
}
setInterval(renderTimeline, 60000);

/* ---------------- CALCULADORA ---------------- */
let rol = "conductor";
const inputs = { km: $("#cKm"), dias: $("#cDias"), pas: $("#cPas"), rend: $("#cRend"), precio: $("#cPrecio") };

function paintRange(el) {
  el.style.setProperty("--p", ((el.value - el.min) / (el.max - el.min)) * 100 + "%");
}

function animateNumber(el, to, fmt) {
  const from = +(el.dataset.v || 0);
  el.dataset.v = to;
  const t0 = performance.now();
  const tick = t => {
    const p = Math.min((t - t0) / 500, 1);
    el.textContent = fmt(from + (to - from) * (1 - Math.pow(1 - p, 3)));
    if (p < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

function calcular() {
  const km = +inputs.km.value, dias = +inputs.dias.value, pas = +inputs.pas.value;
  const rend = +inputs.rend.value, precio = +inputs.precio.value;
  Object.values(inputs).forEach(paintRange);

  $("#oKm").textContent = km + " km";
  $("#oDias").textContent = dias + (dias === 1 ? " día" : " días");
  $("#oPas").textContent = pas;
  $("#oRend").textContent = rend + " km/L";
  $("#oPrecio").textContent = "$" + precio.toFixed(2);

  const kmMes = km * 2 * dias * 4.3;             // ida y vuelta, 4.3 semanas
  const litrosMes = kmMes / (rol === "conductor" ? rend : 14);
  const gasMes = litrosMes * precio;
  let ahorro, barras, litrosAhorro, horas, nota;

  if (rol === "conductor") {
    const tuParte = gasMes / (pas + 1);
    ahorro = gasMes - tuParte;
    litrosAhorro = litrosMes * pas;                  // tus compañeros dejan su coche en casa
    barras = [
      { label: "Manejando solo", val: gasMes, color: "#E5484D" },
      { label: `Con Rodando (${pas + 1} personas)`, val: tuParte, color: "#16C47F" }
    ];
    $("#rLabel").textContent = "Recuperas al mes";
    nota = `Gastas ${money(gasMes)} de gasolina al mes. Dividido entre ${pas + 1} personas, a ti solo te toca ${money(tuParte)}. Los ${Math.round(litrosAhorro)} L ahorrados salen de los coches que tus compañeros ya no usan.`;
  } else {
    const viajes = dias * 2 * 4.3;
    const uber = viajes * (CONFIG.tarifaUberBase + km * CONFIG.tarifaUberKm);
    const transporte = viajes * CONFIG.pasajeTransporte * (km > 10 ? 3 : 2);
    const rodando = gasMes / 4;                    // coche con 4 personas
    ahorro = uber - rodando;
    litrosAhorro = litrosMes * 0.75;
    horas = viajes * (km > 10 ? 0.6 : 0.35);
    barras = [
      { label: "Uber / DiDi", val: uber, color: "#E5484D" },
      { label: `Transporte público (${km > 10 ? 3 : 2} camiones)`, val: transporte, color: "#FF8A3D" },
      { label: "Rodando UTP", val: rodando, color: "#16C47F" }
    ];
    $("#rLabel").textContent = "Te ahorras al mes (vs. Uber)";
    nota = `Comparado con el transporte público ahorras ${money(Math.max(transporte - rodando, 0))} al mes y ${Math.round(horas)} horas de camión.`;
  }

  animateNumber($("#rMes"), ahorro, money);
  animateNumber($("#rCuatri"), ahorro * 4, money);
  animateNumber($("#rCo2"), litrosAhorro * CONFIG.co2PorLitro, v => Math.round(v) + " kg");
  animateNumber($("#rLitros"), litrosAhorro, v => Math.round(v) + " L");
  if (rol === "conductor") {
    animateNumber($("#rTiempo"), pas * dias * 2 * 4.3, v => Math.round(v));
    $("#rTiempoLbl").textContent = "asientos llenos al mes";
  } else {
    animateNumber($("#rTiempo"), horas, v => Math.round(v) + " h");
    $("#rTiempoLbl").textContent = "menos en transporte";
  }
  $("#rNote").textContent = nota;

  const max = Math.max(...barras.map(b => b.val));
  $("#bars").innerHTML = barras.map(b => `
    <div class="bar">
      <div class="bar__head"><span>${b.label}</span><b>${money(b.val)}/mes</b></div>
      <div class="bar__track"><div class="bar__fill" style="background:${b.color}" data-w="${(b.val / max) * 100}"></div></div>
    </div>`).join("");
  requestAnimationFrame(() => requestAnimationFrame(() =>
    $$(".bar__fill").forEach(f => f.style.width = f.dataset.w + "%")));
}

Object.values(inputs).forEach(el => el.addEventListener("input", calcular));
$("#cZona").addEventListener("change", e => { inputs.km.value = zonaById(e.target.value).km; calcular(); });
$$("[data-rol]").forEach(b => b.addEventListener("click", () => {
  rol = b.dataset.rol;
  $$("[data-rol]").forEach(x => x.classList.toggle("active", x === b));
  $("#wrapPas").hidden = rol !== "conductor";
  $("#wrapRend").hidden = rol !== "conductor";
  calcular();
}));

/* ---------------- TESTIMONIOS (carrusel) ---------------- */
const colores = ["#FF8A3D", "#16C47F", "#8B5CF6", "#0EA5E9"];
$("#carouselTrack").innerHTML = TESTIMONIOS.map((t, i) => `
  <div class="quote"><div class="quote__box">
    <p class="quote__text">${t.texto}</p>
    <div class="quote__who"><div class="avatar" style="background:${colores[i % 4]}">${initials(t.nombre)}</div>
    <div><b>${t.nombre}</b><small>${t.rol}</small></div></div>
  </div></div>`).join("");
$("#carouselDots").innerHTML = TESTIMONIOS.map((_, i) => `<button aria-label="Testimonio ${i + 1}" data-i="${i}"></button>`).join("");
let slide = 0, slideTimer;
function goSlide(i) {
  slide = (i + TESTIMONIOS.length) % TESTIMONIOS.length;
  $("#carouselTrack").style.transform = `translateX(-${slide * 100}%)`;
  $$("#carouselDots button").forEach((b, j) => b.classList.toggle("active", j === slide));
  clearInterval(slideTimer);
  slideTimer = setInterval(() => goSlide(slide + 1), 5500);
}
$$("#carouselDots button").forEach(b => b.addEventListener("click", () => goSlide(+b.dataset.i)));
// Deslizar con el dedo en el celular
let touchX = null;
$("#carousel").addEventListener("touchstart", e => touchX = e.touches[0].clientX, { passive: true });
$("#carousel").addEventListener("touchend", e => {
  if (touchX === null) return;
  const dx = e.changedTouches[0].clientX - touchX;
  if (Math.abs(dx) > 40) goSlide(slide + (dx < 0 ? 1 : -1));
  touchX = null;
});
goSlide(0);

/* ---------------- FORMULARIO DE CONDUCTOR ---------------- */
$("#driverForm").addEventListener("submit", e => {
  e.preventDefault();
  let ok = true;
  const check = (id, valid, msg) => {
    const f = $(id).closest(".field");
    f.classList.toggle("invalid", !valid);
    f.querySelector(".err").textContent = valid ? "" : msg;
    if (!valid) ok = false;
  };
  const nombre = $("#dNombre").value.trim();
  check("#dNombre", nombre.split(/\s+/).length >= 2, "Escribe tu nombre y apellido.");
  check("#dCorreo", /^[^\s@]+@utpuebla\.edu\.mx$/i.test($("#dCorreo").value.trim()), "Usa tu correo institucional @utpuebla.edu.mx");
  check("#dAuto", $("#dAuto").value.trim().length >= 3, "Dinos qué coche tienes.");
  check("#dHora", !!$("#dHora").value, "Elige una hora.");
  const acepto = $("#dAcepto").checked;
  $("#errAcepto").textContent = acepto ? "" : "Debes aceptar el reglamento.";
  if (!acepto) ok = false;
  if (!ok) { toast("⚠️ Revisa los campos marcados"); return; }

  const z = zonaById($("#dZona").value);
  openModal(`
    <div class="success">
      <div class="success__icon">🚗</div>
      <h3 style="margin-right:0">¡Bienvenido a bordo, ${nombre.split(" ")[0]}!</h3>
      <p style="color:var(--muted)">Tu ruta <b style="color:var(--ink)">${z.nombre} → UTP</b> a las <b style="color:var(--ink)">${$("#dHora").value}</b> con ${$("#dLugares").value} lugar(es) quedó en revisión.
      Te avisaremos a <b style="color:var(--ink)">${$("#dCorreo").value.trim()}</b> cuando esté publicada.</p>
      <p style="font-weight:700">Aportación sugerida por pasajero: ${money(Math.max(10, Math.round(z.km * 1.8 / 5) * 5))}</p>
      <button class="btn btn--dark btn--block" data-close>Entendido</button>
    </div>`);
  e.target.reset();
});

/* ---------------- Notificaciones (toasts) ---------------- */
function toast(msg) {
  const t = document.createElement("div");
  t.className = "toast";
  t.textContent = msg;
  $("#toasts").appendChild(t);
  setTimeout(() => { t.classList.add("out"); setTimeout(() => t.remove(), 300); }, 2800);
}

/* ---------------- PWA: instalación y modo offline ---------------- */
let deferredPrompt = null;
addEventListener("beforeinstallprompt", e => {
  e.preventDefault();
  deferredPrompt = e;
  $("#installBtn").hidden = false;
});
$("#installBtn").addEventListener("click", async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  if (outcome === "accepted") toast("📲 ¡Rodando UTP instalada!");
  deferredPrompt = null;
  $("#installBtn").hidden = true;
});
addEventListener("appinstalled", () => { $("#installBtn").hidden = true; });

const updateOnline = () => $("#offlineBar").classList.toggle("show", !navigator.onLine);
addEventListener("online", () => { updateOnline(); toast("✅ Conexión recuperada"); });
addEventListener("offline", updateOnline);
updateOnline();

if ("serviceWorker" in navigator && location.protocol !== "file:") {
  addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));
}

/* ---------------- Inicio ---------------- */
$("#year").textContent = new Date().getFullYear();
buildMap();
renderRides();
renderMyTrips();
renderDayTabs();
renderTimeline();
calcular();
onScroll();
